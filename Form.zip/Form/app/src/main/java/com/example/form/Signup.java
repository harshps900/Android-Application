package com.example.form;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.form.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Objects;

public class Signup extends AppCompatActivity {

    TextInputEditText name,email1,username,pass,cnf;

    Button rbtn;
    FirebaseAuth firebaseAuth;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_signup);
        initView();


        rbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String namee = Objects.requireNonNull(name.getText()).toString().trim();
                String un = Objects.requireNonNull(username.getText()).toString().trim();
                String emm = Objects.requireNonNull(email1.getText()).toString().trim();
                String cnff = Objects.requireNonNull(cnf.getText()).toString().trim();
                String pswrd = Objects.requireNonNull(pass.getText()).toString().trim();

                firebaseAuth.createUserWithEmailAndPassword(emm, pswrd).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(Signup.this, "User Registered", Toast.LENGTH_SHORT).show();
                    }
                });

                HashMap<String, String> data = new HashMap<>();
                data.put("Name", namee);
                data.put("user_name", un);
                data.put("email", emm);
                data.put("Cnf_password", cnff);
                data.put("Password", pswrd);
                databaseReference.push().setValue(data);
                Intent my_intent = new Intent(Signup.this, Login.class);
                startActivity(my_intent);
                Toast.makeText(Signup.this, "Registration Successful", Toast.LENGTH_SHORT).show();
            }
        });


    }public void initView(){
        name=findViewById(R.id.name1);
        username=findViewById(R.id.username1);
        cnf=findViewById(R.id.cnf_paswrd);
        email1=findViewById(R.id.email2);
        pass=findViewById(R.id.pswrd);
        rbtn=findViewById(R.id.signupp);
        firebaseAuth=FirebaseAuth.getInstance();
        firebaseDatabase=FirebaseDatabase.getInstance();
        databaseReference=firebaseDatabase.getReference().child("User");
    }
}